package vn.devpro.bookmanager_nguyetntp07092;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import vn.devpro.bookmanager_quannvph07250.R;

public class TrangChuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trang_chu);
        setTitle("QUẢN LÝ SÁCH");

    }
}
