package vn.devpro.bookmanager_nguyetntp07092;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import vn.devpro.bookmanager_quannvph07250.R;

public class LoginActivity extends AppCompatActivity {

    private EditText edUser, edPass;
    private Button btnLogin, btnCancel;
    private CheckBox chkRemember;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edUser = findViewById(R.id.edUser);
        edPass = findViewById(R.id.edPass);
        btnLogin = findViewById(R.id.btnLogin);
        btnCancel = findViewById(R.id.btnCancel);
        chkRemember = findViewById(R.id.chkRemember);


    }

    public void openNew(View view) {
        if (edUser.getText().toString().equals("")){
            edUser.setError("Hãy nhập tài khoản");
            return;
        } else if (edPass.getText().toString().equals("")){
            edPass.setError("Hãy nhập mật khẩu");
            return;
        } else {
            if (edUser.getText().toString().equals("admin") && edPass.getText().toString().equals("admin")){
                Intent intent = new Intent(LoginActivity.this, TrangChuActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(LoginActivity.this, "Tài khoản hoặc mật khẩu không chính xác",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void clear(View view) {
        edUser.setText("");
        edPass.setText("");
    }
}
